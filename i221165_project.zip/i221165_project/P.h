

struct Players {
    std::string name;
    int score;
};

bool operator<(const Players& a, const Players& b) {
    return a.score > b.score; // sort in descending order
}

void addPlayer(std::ostream& outputStream, const Players& player) {
    outputStream << player.name << " " << player.score << std::endl;
}

void readPlayers(std::istream& inputStream, Players players[], int size) {
    for (int i = 0; i < size; ++i) {
        if (inputStream >> players[i].name >> players[i].score) {
            continue;
        }
        else {
            break;
        }
    }
}

Players findPlayer(const std::string& name, const Players players[], int size) {
    for (int i = 0; i < size; ++i) {
        if (players[i].name == name) {
            return players[i];
        }
    }
    return {"", -1};
}