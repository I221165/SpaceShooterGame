
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <time.h>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <iostream>
using namespace std;
#include "player.h"
#include "Enemy.h"
const char title[] = "OOP-Project, Spring-2023";
using namespace sf;

class Game
{
public:
Sprite background; //Game background sprite
Sprite background1; //Game background sprite
Texture bg_texture;
Player* p; //player 
Enemy** E;

float score;
float LivesOfPlayer;
float Level=1;
// add other game attributes


Game()
{
p=new Player("img/player_ship.png");
bg_texture.loadFromFile("img/background.jpg");
background.setTexture(bg_texture);
background1.setTexture(bg_texture);
background.setScale(2, 1.5);
background1.setScale(2, 1.5);
  E =  new Enemy*[20];

 
E[1] = new Alphaa ("img/enemy_1.png",90,90);
E[0] = new Betaa ("img/enemy_1.png",150,90);
E[3] = new Gammaa ("img/enemy_1.png",210,90);
E[4] = new Betaa ("img/enemy_1.png",270,90);
E[5] = new Gammaa ("img/enemy_1.png",330,90);
E[6] = new Alphaa ("img/enemy_1.png",400,90);
E[7] = new Betaa ("img/enemy_1.png",90,130);
E[2] = new Gammaa ("img/enemy_1.png",10,200);

E[10] = new Alphaa ("img/enemy_1.png",90,270);
E[11] = new Betaa ("img/enemy_2.png",580,130);
E[12] = new Gammaa ("img/enemy_3.png",580,200);
E[13] = new Betaa ("img/enemy_1.png",580,1270);

E[14] = new Alphaa ("img/enemy_1.png",580,270);
E[15] = new Betaa ("img/enemy_2.png",580,270);
E[16] = new Gammaa ("img/enemy_3.png",90,270);

E[17] = new Alphaa ("img/enemy_1.png",210,270);
E[18] = new Betaa ("img/enemy_2.png",270,270);
E[19] = new Gammaa ("img/enemy_3.png",340,270);

LivesOfPlayer=20;
score=0;

E[8] = new Monster ("img/monster1.png" , 80 , 80);
E[9] = new Dragon ("img/dragon2.png",200,200);

}
void start_game()
{
    srand(time(0));
    RenderWindow window(VideoMode(780, 780), title);
    Clock clock;
    Clock newclock; 

background.setPosition(0, 0);  // Position the sprite at the top-left corner of the screen
background1.setPosition(0, -780);  // Position the sprite at the top-left corner of the screen

float backgroundScrollSpeed = 0.50f;  // Adjust the scroll speed as desired


    Clock alphaClock;
    Clock betaClock;
    Clock gammaClock;
///////////////////////////////

sf::Clock clocker;
    float totalTime=0;
////////////////////////////////
std::string fontPath = "/home/hamza/Desktop/FOR SFML/Spaceshooter (1)/Spaceshooter/text/BelieveIt-DvLE.ttf";

// Load the font from the file
sf::Font font;
if (!font.loadFromFile(fontPath)) {
    // Error: font file not found or couldn't be loaded
}


sf::Text scoreText;
scoreText.setFont(font);
scoreText.setCharacterSize(24);
scoreText.setFillColor(sf::Color::White);
scoreText.setPosition(10, 10); // Adjust the position as needed

sf::Text timeText;
timeText.setFont(font);
timeText.setCharacterSize(24);
timeText.setFillColor(sf::Color::White);
timeText.setPosition(550, 10); // Adjust the position as needed



//////////////////////////////
float L=0;
float M=0;
float N=0;
int direction;
    float timer=0;
    int score;
    bool inScreen =true;
    bool inScreenleft=true;
    bool inScreenright=false;
    Time EclapsedTime = clock.getElapsedTime();

    sf::Music menuMusic;
    if (!menuMusic.openFromFile("music/other_music.ogg"))
    {
        // Error loading music file
    }
    menuMusic.setLoop(true);
    menuMusic.play();

    while (window.isOpen())
    {
        float time = clock.getElapsedTime().asSeconds(); 
        clock.restart();
        timer += time;  
    

 	Event e;
        while (window.pollEvent(e))
        {  
            if (e.type == Event::Closed) // If cross/close is clicked/pressed
                window.close(); //close the game                        	    
        }
          
sf::String timeString = "Time: " + std::to_string(timer);

// Update the time text
timeText.setString(timeString);


	if (Keyboard::isKeyPressed(Keyboard::Left)) //If left key is pressed
           { //p->move("l");  
            p->rotatedFunction("img/player_ship3.png");
            p->move("l");

            }  // Player will move to left
            else
            {
            }
	if (Keyboard::isKeyPressed(Keyboard::Right)) // If right key is pressed
            {
              
            p->rotatedFunction("img/player_ship1.png");
          p->move("r");
            }  //player will move to right
            else
            {
            }
	if (Keyboard::isKeyPressed(Keyboard::Up)) //If up key is pressed
            {
              
           p->rotatedFunction("img/player_ship.png");
            p->move("u");
            }    //playet will move upwards
            else
            {

            }
	if (Keyboard::isKeyPressed(Keyboard::Down)) // If down key is pressed
     {
      p->rotatedFunction("img/player_ship2.png");
       
                        p->move("d");
    }
else
{
}
if(Keyboard::isKeyPressed(Keyboard::Up) && Keyboard::isKeyPressed(Keyboard::Right))
{

               p->rotatedFunction("img/rotate1.png");
}
else
{
}
if(Keyboard::isKeyPressed(Keyboard::Up) && Keyboard::isKeyPressed(Keyboard::Left))
{

               p->rotatedFunction("img/rotate2.png");
}
else
{
}

if(Keyboard::isKeyPressed(Keyboard::Down) && Keyboard::isKeyPressed(Keyboard::Left))
{

               p->rotatedFunction("img/rotate3.png");
}
else
{
}
if(Keyboard::isKeyPressed(Keyboard::Down) && Keyboard::isKeyPressed(Keyboard::Right))
{

               p->rotatedFunction("img/rotate4.png");
}
else{

}
	if (Keyboard::isKeyPressed(Keyboard::P)) // If down key is pressed
{



}



	////////////////////////////////////////////////
	/////  Call your functions here            ////
p->WrapAround();
scoreText.setString("Score: " + std::to_string(score));
/////////////////////////IF THEY ARE TOUChING //////////////////////////////////

sf::FloatRect bounds1 = p->sprites.getGlobalBounds();

for(int i=0;i<20;i++)
{
sf::FloatRect bounds2 = E[i]->EnemySprite.getGlobalBounds();



if (bounds1.left < bounds2.left + bounds2.width &&
    bounds1.left + bounds1.width > bounds2.left &&
    bounds1.top < bounds2.top + bounds2.height &&
    bounds1.top + bounds1.height > bounds2.top) {
    // Collision occurred
    // Handle collision logic here

LivesOfPlayer--;

p->sprite.setPosition(340,577);


} else {
    // No collision
    // Continue with other game logic
}

}



sf::FloatRect bounds4 = p->sprites.getGlobalBounds();
for(int i=0;i<20;i++)
{
sf::FloatRect bounds3 = E[i]->bomb[i].BombSprite.getGlobalBounds();


if (bounds4.left < bounds3.left + bounds3.width &&
    bounds4.left + bounds4.width > bounds3.left &&
    bounds4.top < bounds3.top + bounds3.height &&
    bounds4.top + bounds4.height > bounds3.top) {
    // Collision occurred
    // Handle collision logic here

LivesOfPlayer--;

p->sprite.setPosition(340,600);


} else {
    // No collision
    // Continue with other game logic
}

}

if(LivesOfPlayer <= 0)
{
    window.close();
}

sf::FloatRect bounds5 = p->bull.FireSprite.getGlobalBounds();
for(int i=0;i<20;i++)
{
sf::FloatRect bounds6 = E[i]->EnemySprite.getGlobalBounds();


if (bounds5.left < bounds6.left + bounds6.width &&
    bounds5.left + bounds5.width > bounds6.left &&
    bounds5.top < bounds6.top + bounds6.height &&
    bounds5.top + bounds5.height > bounds6.top) {
    // Collision occurred
    // Handle collision logic here


E[i]->EnemySprite.setPosition(800,800);
p->bull.FireSprite.setPosition(800,800);
} else {
    // No collision
    // Continue with other game logic
}

}




////////////////////////////////////////////////////////////






	if (Keyboard::isKeyPressed(Keyboard::Space)) // If down key is pressed
{

p->fire("img/pop.png");

}

for(int i=0;i<20;i++)
{

if(i!= 8 && i!=9)
{
    E[i]->bomb[i].update(time);

}

}

/////////////////////////////////////////////////////////////

background.move(0, backgroundScrollSpeed);
    background1.move(0, backgroundScrollSpeed);



if (background.getPosition().y >= 780) {
        background.setPosition(0, -780);
    }
    if (background1.getPosition().y >= 780) {
        background1.setPosition(0, -780);
    }

/////////////////////////////////////////////////////////////
if(p->ShootUp)
{p->bull.moveINUP();}


if(p->ShootDown)
{p->bull.moveINDOWN();}
if(p->ShootLeft)
{p->bull.moveINLEFT();}
if(p->ShootRight)
{p->bull.moveINRIGHT();}
if(p->ShootUpRight)
{p->bull.moveINUPR();}
if(p->ShootUpLeft)
{p->bull.moveINUPL();}

if(p->ShootDownRight)
{p->bull.moveINDOWNR();
}
if(p->ShootDownLeft)
{
p->bull.moveINDOWNL();
}
	//////////////////////////////////////////////

	window.clear(Color::Black); //clears the screen
	window.draw(background);  // setting background
    	window.draw(background1);  // setting background
window.draw(scoreText);
window.draw(timeText);
	window.draw(p->sprite);   // setting player on screen
    
    
if(p->bull.FireSprite.getPosition().y <=0 || p->bull.FireSprite.getPosition().x <=0 || p->bull.FireSprite.getPosition().y >=750 || p->bull.FireSprite.getPosition().x >=750 )
{
    p->bull.FireSprite.setPosition(800,800);
}
/////////////////////////////Game Script////////////////////////////////////////
if(timer > 25.0000 )
{

for(int i=0;i<20;i++)
{
if(i != 8 && i!=9)
{E[i]->EnemySprite.setPosition(800,800);
}

}
    
    E[8]->draw(window);

}
if(timer > 28.000 && timer < 31.000)
{
    E[8]->fire("img/laser.png",8);
    E[8]->bomb[8].draw(window);

}
if(timer > 31.000)
{
    E[8]->EnemySprite.setPosition(800,800);


E[0]->EnemySprite.setPosition(200,200);
E[1]->EnemySprite.setPosition(190,80);
E[2]->EnemySprite.setPosition(180,80);
E[3]->EnemySprite.setPosition(170,80);
E[4]->EnemySprite.setPosition(160,80);
E[5]->EnemySprite.setPosition(150,80);
E[6]->EnemySprite.setPosition(140,80);
E[7]->EnemySprite.setPosition(130,80);
E[10]->EnemySprite.setPosition(120,80);
E[11]->EnemySprite.setPosition(110,80);
E[12]->EnemySprite.setPosition(100,80);
E[13]->EnemySprite.setPosition(90,80);
E[14]->EnemySprite.setPosition(80,80);
E[15]->EnemySprite.setPosition(70,80);
E[16]->EnemySprite.setPosition(60,80);
E[17]->EnemySprite.setPosition(50,80);
E[18]->EnemySprite.setPosition(40,80);
E[19]->EnemySprite.setPosition(30,80);



}


if(timer > 42.000 && timer < 48.000)
{
    E[9]->draw(window);
}
if(timer > 49.000 && timer < 54.000)
{


if(timer > 51.0000 && timer < 54.0000)
{E[8]->fire("img/laser.png",8);
    E[8]->bomb[8].draw(window);
}

}

//////////////////////////////////////////////////////////////////////////

window.draw(p->bull.FireSprite);

p->adders.Movement();

E[0]->draw(window);
E[1]->draw(window);
E[3]->draw(window);
E[4]->draw(window);
E[5]->draw(window);
E[6]->draw(window);
E[7]->draw(window);



//////////////////////////////////////////////////

////////////////MONSTER ROTATION///////////////////////
    
if (E[8]->EnemySprite.getPosition().x <=20 )  {
    
    inScreen=false;
    inScreenleft=true;
} 
else if (E[8]->EnemySprite.getPosition().x >= 500)
{
    inScreen=true;
    inScreenleft=false;

}
//////////////////////MONSTER FIRE//////////////////////////////////////////



if (inScreen ) {
E[8]->move(-0.2);
}
else if (inScreenleft)
{    
    E[8]->move(0.2);
}
//////////////////////////////////////////////////////////////




E[1]->bomb[1].draw(window);
E[2]->bomb[2].draw(window);

E[3]->bomb[3].draw(window);

E[4]->bomb[4].draw(window);

E[5]->bomb[5].draw(window);

E[6]->bomb[7].draw(window);


E[9]->bomb[9].draw(window);

E[11]->bomb[11].draw(window);

E[12]->bomb[12].draw(window);

E[13]->bomb[13].draw(window);

E[15]->bomb[15].draw(window);

E[16]->bomb[16].draw(window);

E[18]->bomb[18].draw(window);

E[19]->bomb[19].draw(window);


E[6]->bomb[6].draw(window);
E[10]->bomb[10].draw(window);
E[14]->bomb[14].draw(window);
E[17]->bomb[17].draw(window);




for(int i=10;i<20 ;i++)
{
if(i !=8)
{
E[i]->draw(window);
}
}
    //////////////////////////////////////////
    

float tamee=gammaClock.getElapsedTime().asSeconds();
betaClock.restart();

N+=tamee;


if ( N >= 2) {

E[2]->fire("img/bomb.png",2);

E[3]->fire("img/bomb.png",3);
E[5]->fire("img/bomb.png",5);
E[12]->fire("img/bomb.png",12);
E[16]->fire("img/bomb.png",16);
E[19]->fire("img/bomb.png",19);


cout<<N<<endl;
N=0;
}


///////////////////////////////////////////////


float totall=clocker.getElapsedTime().asSeconds();
clocker.restart();

totalTime+=totall;


if ( totalTime >= 15) {
float anotherRandom = rand() % 4;

cout<<score<<endl;

if(anotherRandom == 1)
{

float random = rand() % 700;
p->AddersDeployment("img/PNG/Power-ups/powerupBlue_star.png",random);
}
else if (anotherRandom == 2)
{
float random = rand() % 700;
p->AddersDeployment("img/PNG/Power-ups/powerupBlue_shield.png",random);

}
else if (anotherRandom =3 )
{
float random = rand() % 700;
p->AddersDeployment("img/PNG/Power-ups/powerupBlue_bolt.png",random);

}
else
{
float random = rand() % 700;
p->AddersDeployment("img/PNG/Meteors/meteorBrown_big3.png",random);

}
cout<<totalTime<<"  "<<endl;

totalTime=0;
}

float tame=gammaClock.getElapsedTime().asSeconds();
gammaClock.restart();

M+=tame;


if ( M >= 3) {

E[0]->fire("img/bomb.png",0);

E[4]->fire("img/bomb.png",4);
E[7]->fire("img/bomb.png",7);
E[11]->fire("img/bomb.png",11);
E[13]->fire("img/bomb.png",13);
E[15]->fire("img/bomb.png",15);
E[18]->fire("img/bomb.png",18);

cout<<M<<endl;
M=0;
}



float deltatime =alphaClock.getElapsedTime().asSeconds();
alphaClock.restart();

L+=deltatime;

if ( L >= 5) {
    E[17]->fire("img/bomb.png",17);

E[1]->fire("img/bomb.png",1);
E[6]->fire("img/bomb.png",6);
E[10]->fire("img/bomb.png",10);
E[14]->fire("img/bomb.png",14);
cout<<L<<endl;
L=0;
        }
        


p->adders.draw(window);
//////////////////////////////////////////////
	window.display();  //Displying all the sprites
    }



}

~Game()
{
for (int i = 0; i < 20; ++i) {
            delete E[i];
        }

}

};

