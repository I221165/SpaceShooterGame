#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include<string.h>
#include <fstream>
#include <sstream>
using namespace sf;



class AddON {
public:
Texture addtex;
Sprite AddOnSprite;
int x;
int y;

AddON(){}

AddON(std::string png_path){


addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(0,0);
AddOnSprite.setScale(0.75,0.75);


}

 
virtual void AddOnTex(std::string png_path,int x)
{

addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(x,0);
AddOnSprite.setScale(0.75,0.75);
  
}

virtual void Movement()

{

AddOnSprite.setPosition(AddOnSprite.getPosition().x,(AddOnSprite.getPosition().y)+0.1);

}

virtual void draw(sf::RenderWindow& window) {
        
        window.draw(AddOnSprite);
    }



};




class BulletFire : public AddON {
public:

BulletFire(std::string png_path, int x , int y) : AddON(png_path){


addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(x,y);
AddOnSprite.setScale(0.75,0.75);



}


virtual void AddOnMovement(std::string png_path)
{

addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(0,0);
AddOnSprite.setScale(0.75,0.75);

  
}
virtual void Movement()

{

AddOnSprite.setPosition(AddOnSprite.getPosition().x,(AddOnSprite.getPosition().y)+0.1);

}

virtual void draw(sf::RenderWindow& window) {
        
        window.draw(AddOnSprite);
    }
    

};




class Lives : public AddON {
public:

Lives(std::string png_path, int x , int y) : AddON(png_path){


addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(x,y);
AddOnSprite.setScale(0.75,0.75);



}


virtual void AddOnMovement(std::string png_path)
{

addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(0,0);
AddOnSprite.setScale(0.75,0.75);

  
}
virtual void Movement()

{

AddOnSprite.setPosition(AddOnSprite.getPosition().x,(AddOnSprite.getPosition().y)+0.1);

}

virtual void draw(sf::RenderWindow& window) {
        
        window.draw(AddOnSprite);
    }
    




};








class Danger : public AddON {
public:

Danger(std::string png_path, int x , int y) : AddON(png_path){


addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(x,y);
AddOnSprite.setScale(0.75,0.75);



}

virtual void AddOnMovement(std::string png_path)
{

addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(0,0);
AddOnSprite.setScale(0.75,0.75);

  
}
virtual void Movement()

{

AddOnSprite.setPosition(AddOnSprite.getPosition().x,(AddOnSprite.getPosition().y)+0.1);

}

virtual void draw(sf::RenderWindow& window) {
        
        window.draw(AddOnSprite);
    }
    

};





class PowerON : public AddON {
public:


PowerON(std::string png_path, int x , int y) : AddON(png_path){


addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(x,y);
AddOnSprite.setScale(0.75,0.75);



}

virtual void AddOnTex(std::string png_path)
{

addtex.loadFromFile(png_path);
AddOnSprite.setTexture(addtex);
AddOnSprite.setPosition(0,0);
AddOnSprite.setScale(0.75,0.75);

  
}
virtual void Movement()

{

AddOnSprite.setPosition(AddOnSprite.getPosition().x,(AddOnSprite.getPosition().y)+0.1);

}
virtual void draw(sf::RenderWindow& window) {
        
        window.draw(AddOnSprite);
    }
    

};





