

class Gammaa : public Invader
{
public:
Gammaa(std::string png_path,int x , int y) : Invader(png_path,x,y) {

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);

EnemySprite.setPosition(x,y);
EnemySprite.setScale(0.55,0.55);
}


void move(float x) override{}

void fire (std::string png_path, int i) override{

	bomb[i].DropBOMB(png_path,EnemySprite.getPosition().x,EnemySprite.getPosition().y);



}


};

