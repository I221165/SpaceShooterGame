#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include<string.h>
#include <fstream>
#include "Bomb.h"
#include <sstream>
using namespace sf;
#include <time.h>

class Enemy{
public:

Texture Enemytex;

Sprite EnemySprite;


float speed =0.3;
int x,y;

Bomb bomb[20];


Enemy(std::string png_path,int x , int y)
{

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);



}

virtual void draw(sf::RenderWindow& window) {
        // Draw the sprite to the window
        window.draw(EnemySprite);
    }



virtual void move ( float x) = 0;

virtual void  fire(std::string png_path, int i) = 0;



};


class Invader : public Enemy {
public:

Invader(std::string png_path,int x , int y) : Enemy(png_path,x,y) {

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);

EnemySprite.setPosition(x,y);
EnemySprite.setScale(0.5,0.5);


}

virtual void draw(sf::RenderWindow& window) {
        
        window.draw(EnemySprite);
    }
    
void move(float x) override{

int sey = EnemySprite.getPosition().y;
int sexxxx = EnemySprite.getPosition().x;

sexxxx+=0.2;

EnemySprite.setPosition(sexxxx,sey);

}

void fire (std::string png_path , int i) override{

	bomb[i].DropBOMB(png_path,EnemySprite.getPosition().x,EnemySprite.getPosition().y);



}


};





class Monster : public Enemy {
public:

float speed = 0.1;

Monster(std::string png_path , int x , int y) : Enemy(png_path,x,y) {

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);

EnemySprite.setPosition(x,y);
EnemySprite.setScale(0.5,0.5);


}

virtual void draw(sf::RenderWindow& window) {
 
        window.draw(EnemySprite);
    }


void move(float x) override{

EnemySprite.setPosition((EnemySprite.getPosition().x)+x,EnemySprite.getPosition().y);

}

void fire (std::string png_path, int i) override{

	bomb[i].DropBOMB(png_path,(EnemySprite.getPosition().x)+145,(EnemySprite.getPosition().y)+220);



}


};




class Dragon : public Enemy {
public:


Dragon(std::string png_path,int x , int y) : Enemy(png_path,x,y) {

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);

EnemySprite.setPosition(x,y);
EnemySprite.setScale(0.5,0.5);


}

virtual void draw(sf::RenderWindow& window) {
        
        window.draw(EnemySprite);
    }
void move(float x) override{}

void fire (std::string png_path, int i) override{

	bomb[i].DropBOMB(png_path,EnemySprite.getPosition().x,EnemySprite.getPosition().y);



}


};


class Alphaa : public Invader
{
public:
Alphaa(std::string png_path,int x , int y) : Invader(png_path,x,y) {

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);

EnemySprite.setPosition(x,y);
EnemySprite.setScale(0.55,0.55);
}

void move(float x) override{}

void fire (std::string png_path, int i) override{

	bomb[i].DropBOMB(png_path,EnemySprite.getPosition().x,EnemySprite.getPosition().y);



}




};


class Betaa : public Invader
{
public:
Betaa(std::string png_path,int x , int y) : Invader(png_path,x,y) {

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);

EnemySprite.setPosition(x,y);
EnemySprite.setScale(0.55,0.55);
}



void move(float x) override{}

void fire (std::string png_path, int i) override{

	bomb[i].DropBOMB(png_path,EnemySprite.getPosition().x,EnemySprite.getPosition().y);



}


};


class Gammaa : public Invader
{
public:
Gammaa(std::string png_path,int x , int y) : Invader(png_path,x,y) {

Enemytex.loadFromFile(png_path);

        EnemySprite.setTexture(Enemytex);

EnemySprite.setPosition(x,y);
EnemySprite.setScale(0.55,0.55);
}


void move(float x) override{}

void fire (std::string png_path, int i) override{

	bomb[i].DropBOMB(png_path,EnemySprite.getPosition().x,EnemySprite.getPosition().y);



}


};

