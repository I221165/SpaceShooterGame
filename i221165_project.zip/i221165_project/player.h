#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include<string.h>
#include <fstream>
#include <sstream>
#include "Bullet.h"
#include "AddOn.h"
#include <time.h>

using namespace sf;
class Player{
public:
Texture tex;


Sprite sprite;
Sprite sprites;
int LifeOfPlayer = 20;


bool ShootUp=true;
bool ShootDown=false;
bool ShootLeft=false;
bool ShootRight=false;
bool ShootUpLeft=false;
bool ShootUpRight=false;
bool ShootDownLeft=false;
bool ShootDownRight=false;



float speed=0.3;
int x,y;

Bullet bull;

AddON adders;

Player(std::string png_path)

{

tex.loadFromFile(png_path);
sprite.setTexture(tex);
x=340;y=577;
sprite.setPosition(x,y);
sprite.setScale(0.75,0.75);

}

void AddersDeployment(std::string png_path,int x)
{
	adders.AddOnTex(png_path,x);
}


void WrapAround(){

if (sprite.getPosition().x >= 700 )

{sprite.setPosition(0,sprite.getPosition().y);}

else if (sprite.getPosition().x <= 0)
{ sprite.setPosition(700,sprite.getPosition().y); }



if (sprite.getPosition().y < 0 ){
sprite.setPosition(sprite.getPosition().x,700);

}

else if (sprite.getPosition().y > 700 ){
sprite.setPosition(sprite.getPosition().x,0);

}


}

void fire (std::string png_path)
{
	bull.fire(png_path,sprite.getPosition().x,sprite.getPosition().y);
}


void rotatedFunction (std::string png_path){

tex.loadFromFile(png_path);

sprites.setTexture(tex);
x=sprite.getPosition().x;
y=sprite.getPosition().y;
sprites.setPosition(x,y);
sprites.setScale(0.75,0.75);





if(png_path == "img/player_ship.png")
{
	ShootUp=true;
}
else
{
	ShootUp=false;
}



if(png_path == "img/player_ship2.png")
{
ShootDown=true;
}
else
{
	ShootDown=false;
}





if(png_path == "img/player_ship3.png")
{
ShootLeft=true;}
else
{
	ShootLeft=false;
}






if(png_path == "img/player_ship1.png")
{
	ShootRight=true;
}
else
{
	ShootRight=false;
}





if(png_path == "img/rotate2.png")
{
ShootUpLeft=true;}
else
{
	ShootUpLeft=false;
}




if(png_path == "img/rotate1.png")
{
	ShootUpRight=true;
}
else
{
	ShootUpRight=false;
}





if(png_path == "img/rotate3.png")
{
	ShootDownLeft=true;
}
else
{
	ShootDownLeft=false;
}



if(png_path == "img/rotate4.png")
{
	ShootDownRight=true;
}
else
{
	ShootDownRight=false;
}




}

void move(std::string s){
float delta_x=0,delta_y=0;
if(s=="l")
	//move the player left
	
	{delta_x=-1;}
else if(s=="r")
	
{delta_x = 1;}
	//move the player right
if(s=="u")
	
	{delta_y=-1;}
else if(s=="d")
	
	{delta_y=1;}

delta_x*=speed;
delta_y*=speed;

sprite.move(delta_x, delta_y);

}



};
