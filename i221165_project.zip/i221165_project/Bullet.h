#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include<string.h>
#include <fstream>
#include <sstream>
using namespace sf;

class Bullet {

public:

Texture bullettex;
Sprite FireSprite ;
int x,y;


Bullet (){}

Bullet(std::string png_path )
{


bullettex.loadFromFile(png_path);
FireSprite.setTexture(bullettex);
x=300;y=720;
FireSprite.setPosition(x,y);
FireSprite.setScale(0.75,0.75);

}


void fire( std::string png_path,int x , int y)
{



bullettex.loadFromFile(png_path);
FireSprite.setTexture(bullettex);

FireSprite.setPosition(x+25,y-50);
FireSprite.setScale(0.75,0.75);


}



void moveINUP()
{


int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;

sey-=0.2;
sexxxx+=0.2;

FireSprite.setPosition(sexxxx,sey);

}

void moveINDOWN()
{

int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;



FireSprite.setPosition(sexxxx,sey+1);

}
void moveINLEFT()
{

int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;


FireSprite.setPosition((sexxxx)-0.4,sey);

}
void moveINRIGHT()
{

int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;


FireSprite.setPosition((sexxxx)+1,sey);

}
void moveINUPL()
{

int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;

sey-=0.2;
sexxxx-=0.4;

FireSprite.setPosition(sexxxx,sey);

}
void moveINUPR()
{

int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;



FireSprite.setPosition(sexxxx+1,sey-1);

}
void moveINDOWNL()
{

int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;

sey+=0.2;
sexxxx-=0.4;

FireSprite.setPosition(sexxxx-0.4,sey+1);

}
void moveINDOWNR()
{

int sey = FireSprite.getPosition().y;
int sexxxx = FireSprite.getPosition().x;


sexxxx+=0.4;

FireSprite.setPosition(sexxxx+1,sey+1);

}


};