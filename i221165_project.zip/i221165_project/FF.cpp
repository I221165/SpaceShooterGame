








#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <string>
#include <iostream>
#include <time.h>

using namespace sf;

class Enemy {
public:
    Texture enemyTexture;
    Sprite enemySprite;

    float speed = 0.3;
    int x, y;

    Enemy(std::string png_path) {
        if (!enemyTexture.loadFromFile(png_path)) {
            std::cerr << "Failed to load texture from file " << png_path << std::endl;
            exit(EXIT_FAILURE);
        }
        enemySprite.setTexture(enemyTexture);
    }

    virtual void move(float speed) {
        x += speed;
        enemySprite.setPosition(x, y);
    }
};

class Invader : public Enemy {
public:
    Invader(std::string png_path) : Enemy(png_path) {}
};

class AlphaBeta : public Invader {
public:
    AlphaBeta(std::string png_path) : Invader(png_path) {}
    void move(float speed) override {
        x += speed;
        enemySprite.setPosition(x, y);
        std::cout << "AlphaBeta moved!" << std::endl;
    }
};

class Gamma : public Invader {
public:
    Gamma(std::string png_path) : Invader(png_path) {}
    void move(float speed) override {
        x += speed;
        enemySprite.setPosition(x, y);
        std::cout << "Gamma moved!" << std::endl;
    }
};

int main() {
    RenderWindow window(VideoMode(800, 600), "Game");

    Enemy* enemies[3];
    enemies[0] = new Invader("invader.png");
    enemies[1] = new AlphaBeta("alphabeta.png");
    enemies[2] = new Gamma("gamma.png");

    Clock alpha_clock, beta_clock, gamma_clock;

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
        }

        // Move AlphaBeta every 5 seconds
        if (alpha_clock.getElapsedTime().asSeconds() >= 5) {
            alpha_clock.restart();
            enemies[1]->move(0.5);
        }

        // Move Beta every 3 seconds
        if (beta_clock.getElapsedTime().asSeconds() >= 3) {
            beta_clock.restart();
            enemies[2]->move(0.5);
        }

        // Move Gamma every 2 seconds
        if (gamma_clock.getElapsedTime().asSeconds() >= 2) {
            gamma_clock.restart();
            enemies[3]->move(0.5);
        }

        window.clear();
        for (int i = 0; i < 3; i++) {
            window.draw(enemies[i]->enemySprite);
        }
        window.display();
    }

    for (int i = 0; i < 3; i++) {
        delete enemies[i];
    }

    return 0;
}













