
#include "game.h"
#include <iostream>
#include<fstream>
#include<string>



class Menu{
public:
Sprite backgroundd;
Texture bgg_texture;
//add menu attributes here
Menu()
{

//constructors body
}

void display_menu()

{

    Game g; 
//display menu screen here

sf::Music menuMusic;
    if (!menuMusic.openFromFile("music/menu_music.ogg"))
    {
        // Error loading music file
    }
    menuMusic.setLoop(true);
    menuMusic.play();



sf::RenderWindow window(sf::VideoMode(780, 780), "Menu Window");
bgg_texture.loadFromFile("img/background1.jpg");
backgroundd.setTexture(bgg_texture);
backgroundd.setScale(1, 1);


sf::CircleShape button1;
button1.setRadius(50);
  
// Define the path to the font file
std::string fontPath = "/home/hamza/Desktop/FOR SFML/Spaceshooter (1)/Spaceshooter/text/BelieveIt-DvLE.ttf";



///////////////
string name;

///////////////



// Load the font from the file
sf::Font font;
if (!font.loadFromFile(fontPath)) {
    // Error: font file not found or couldn't be loaded
}
button1.setPosition(100, 250);
button1.setFillColor(sf::Color::Red);
sf::Text buttonText("SpaceShooter",font,150);
sf::Text buttonText1("StartGame",font,50);
sf::Text buttonText2("HighScore",font,50);
sf::Text newbuttonText1("Close from here",font,50);
sf::Text newbuttonText2("HighScores",font,50);

sf::Text newbuttonText3("Note: Kindly Write your name on Terminal and press ENTER",font,30);


buttonText.setPosition(100, 70);



buttonText.setFillColor(sf::Color::Red);
buttonText.setStyle(sf::Text::Bold);
buttonText.setFillColor(sf::Color::White);

buttonText1.setPosition(100, 250);
buttonText1.setStyle(sf::Text::Bold);
buttonText1.setFillColor(sf::Color::Green);

newbuttonText1.setPosition(50, 50);
newbuttonText1.setStyle(sf::Text::Bold);
newbuttonText1.setFillColor(sf::Color::Green);


newbuttonText2.setPosition(125, 125);
newbuttonText2.setStyle(sf::Text::Bold);
newbuttonText2.setFillColor(sf::Color::Green);



newbuttonText3.setPosition(100, 500);
newbuttonText3.setStyle(sf::Text::Bold);
newbuttonText3.setFillColor(sf::Color::Green);


buttonText2.setPosition(300, 250);
buttonText2.setStyle(sf::Text::Bold);
buttonText2.setFillColor(sf::Color::Green);




// add functionality of all the menu options here

//if Start game option is chosen 
while (window.isOpen()) {
  sf::Event event;
  while (window.pollEvent(event)) {
    if (event.type == sf::Event::Closed) {
      window.close();
    }

    if (event.type == sf::Event::MouseButtonPressed) {
      if (buttonText1.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
ofstream out("TextFile1.txt");
      cin>>name;

	out << name << "||"<< g.score<<endl;
  	out.close();
window.clear(Color::Black); //clears the screen
	window.draw(backgroundd);  // setting background
menuMusic.stop();
window.close();
    g.start_game();
        // Button 1 was clicked!
      }
      else if (buttonText2.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) 

      {
sf::RenderWindow windows(sf::VideoMode(780, 780), "Menu Window");
	ifstream in("TextFile1.txt");

	string content;
  sf::Text newbuttonText4(content,font,50);

		    while (getline(in, content)) {


        }

string newcunt;

sf::Text newbuttonText5(newcunt,font,50);

newbuttonText4.setPosition(300, 250);
newbuttonText4.setStyle(sf::Text::Bold);
newbuttonText4.setFillColor(sf::Color::Green);


newbuttonText5.setPosition(300, 200);
newbuttonText5.setStyle(sf::Text::Bold);
newbuttonText5.setFillColor(sf::Color::Green);


while (windows.isOpen()) {
  sf::Event events;
  while (windows.pollEvent(events)) {
    if (events.type == sf::Event::Closed) {
      windows.close();
    }
if (events.type == sf::Event::MouseButtonPressed) {
if (newbuttonText1.getGlobalBounds().contains(events.mouseButton.x, events.mouseButton.y)) {

      windows.close();

}
}
    }
windows.clear(Color::Black); //clears the screen
	windows.draw(backgroundd);  // setting background
 
windows.draw(newbuttonText4);
windows.draw(newbuttonText5);
windows.draw(newbuttonText1);
  windows.draw(newbuttonText2);

  
  windows.display();



  }






  }
    }
  }



  
  window.clear(Color::Black); //clears the screen
	window.draw(backgroundd);  // setting background
 
  window.draw(buttonText);
  window.draw(buttonText1);
  window.draw(buttonText2);
  window.draw(newbuttonText3);
  
  window.display();
}
    
    



}


};
