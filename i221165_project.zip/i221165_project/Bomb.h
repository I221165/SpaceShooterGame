#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include<string.h>
#include <fstream>
#include <sstream>
#include <time.h>
using namespace sf;


class Bomb{
public:

Texture bombTex;
Sprite BombSprite;
int x,y;

Bomb(){}

Bomb(std::string png_path  )
{


bombTex.loadFromFile(png_path);
BombSprite.setTexture(bombTex);
BombSprite.setPosition(x,y);
BombSprite.setScale(0.75,0.75);


}


void DropBOMB(std::string png_path,int x , int y)
{

bombTex.loadFromFile(png_path);
BombSprite.setTexture(bombTex);

BombSprite.setPosition(x+25,y+50);
BombSprite.setScale(0.5,0.5);
}



void update(float time) {
      
    
int sey = BombSprite.getPosition().y;
int sexxxx = BombSprite.getPosition().x;

BombSprite.setPosition(sexxxx,(sey+1));
    }

    void draw(sf::RenderWindow& window) {
        // Draw the bomb sprite to the window
        window.draw(BombSprite);
    }


};